#include "cardDeckClass.h"
#include <iostream>

// Convert card rank and suit to string
std::string Card::toString() const {
    const std::string ranks[] = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};
    const std::string suits[] = {"Clubs", "Diamonds", "Hearts", "Spades"};
    return ranks[rank - Two] + " of " + suits[suit];
}

// Constructor for Deck, initializes the deck
Deck::Deck() {
    initializeDeck();
}

// Initializes a standard deck of 52 cards
void Deck::initializeDeck() {
    int index = 0;
    for (int suit = Card::Clubs; suit <= Card::Spades; ++suit) {
        for (int rank = Card::Two; rank <= Card::Ace; ++rank) {
            cards[index++] = Card(static_cast<Card::Rank>(rank),                          static_cast<Card::Suit>(suit));
        }
    }
}

// Perform a perfect in-shuffle on the deck
void Deck::perfectShuffle() {
    Card shuffledDeck[DECK_SIZE];
    int index = 0;

    // Shuffle the first half of the deck
    for (int i = 0; i < DECK_SIZE / 2; ++i) {
        shuffledDeck[index++] = cards[i];
        shuffledDeck[index++] = cards[i + DECK_SIZE / 2]; 
    }

    // Copy shuffledDeck back into cards
    for (int i = 0; i < DECK_SIZE; ++i) {
        cards[i] = shuffledDeck[i];
    }
}

// Print the deck of cards
void Deck::printDeck() const {
    for (int i = 0; i < DECK_SIZE; ++i) {
        std::cout << cards[i].toString() << std::endl;
    }
    std::cout << std::endl;
}

// Compare two decks of cards to see if they are in the same order
bool Deck::isEqual(const Deck& other) const {
    for (int i = 0; i < DECK_SIZE; ++i) {
        // Here is the correction!
        if (cards[i].toString() != other.cards[i].toString()) {
            return false;
        }
    }
    return true;
}

// Count the number of perfect shuffles needed to restore the deck to its original order
int Deck::countShufflesToRestore() {
    Deck original = *this;
    int count = 0;
    do {
        perfectShuffle();
        count++;
    } while (!isEqual(original));
    return count;
}