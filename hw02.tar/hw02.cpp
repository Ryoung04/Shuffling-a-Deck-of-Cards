/*******************************************
*
*  Author: Reise Young
*  Student ID: 1239147
*  Assignment: HW02 (Corrections)
*  Class: CS1C
*  Section: 19710
*  Last Modified: September 17, 2024
*
* Description: The primary goal of this program is to demonstrate the concept of * perfect in-shuffles and their properties. It highlights that a perfect in-
* shuffle doesn't necessarily restore a deck to its original order in a single 
* shuffle but might require multiple shuffles to achieve the original 
* configuration.
*
* PRECONDITION: None
*
* POSTCONDITION: A deck of cards is shuffled and printed, and the number of 
* shuffles needed to restore the deck to its original order are printed
*
*******************************************/

// Includes the header file for the Card and Deck Class
#include "cardDeckClass.h"

using namespace std;

// Main function of the program that prints out all the information 
int main() {
    Deck deck;

    cout << endl;
    cout << "Initial Deck of Cards:" << endl;
    cout << endl;
    deck.printDeck();

// Prints the shuffled deck 
    deck.perfectShuffle();
    cout << "Deck after one perfect shuffle:" << endl;
    cout << endl;
    deck.printDeck();

// Calculates the number of shuffles needed to restore the deck to its original order
    int shufflesNeeded = deck.countShufflesToRestore();

    // Print the final deck (restored deck)
    cout << "Final Deck (restored):" << endl;
    cout << endl;
    deck.printDeck();

    cout << "Number of perfect shuffles needed to restore the deck to original order: " << shufflesNeeded << endl;

    return 0;
}