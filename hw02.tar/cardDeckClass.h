/*******************************************
*
*  Author: Reise Young
*  Student ID: 1239147
*  Assignment: HW02
*  Class: CS1C
*  Section: 19710
*  Last Modified: August 29, 2024
*
* PRECONDITION: None
*
*
* POSTCONDITION: Defines the Card and Deck classes and are intialized with a 
* standard deck of 52 cards. 
*
*******************************************/

#ifndef CARDDECKCLASS_H
#define CARDDECKCLASS_H

#include <string>
#include <iostream>

using namespace std;

// Card class definition
class Card {
public:
    // Enumeration for card suits
    enum Suit { Clubs, Diamonds, Hearts, Spades };
    // Enumeration for card ranks 
    enum Rank { Two = 2, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King, Ace };

    // Card constructor 
    Card(Rank rank = Two, Suit suit = Clubs) : rank(rank), suit(suit) {}

    // Method to convert a card to a string
    // Pre-condition: The Card object exists.
    // Post-condition: A string representation of the card is returned.
    string toString() const;

private:
    // Private member variables for card rank and suit 
    Rank rank;
    Suit suit;
};

// Deck class definition
class Deck {
public:
    static const int DECK_SIZE = 52;

    Deck();

    // Functions to shuffle the deck and deal cards 
    void initializeDeck();
    void perfectShuffle();
    void printDeck() const;
    bool isEqual(const Deck& other) const;
    int countShufflesToRestore();

private:
    Card cards[DECK_SIZE];
};

#endif
